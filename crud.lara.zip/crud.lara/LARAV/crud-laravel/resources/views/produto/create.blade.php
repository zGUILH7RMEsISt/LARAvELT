@extends('layouts.main')

@section('titlePage', 'Produto')

@section('content')
    <h3>Produtos</h3>
    <form action="{{ route('produto.store') }}" method="POST">
        @csrf
        <div class="form-group">
            <label>Produto</label>
            <input type="text" name="Produto" class="form-control shadow-none" placeholder="Nome do Produto">
        </div>
        <div class="form-group">
            <label>Preço</label>
            <input type="text" name="Preço" class="form-control shadow-none" placeholder="Preço do Produto">
        </div>
        <div class="form-group">
            <label>Quantidade</label>
            <input type="date" name="date" class="form-control shadow-none" placeholder="Quantidade do Produto">
        </div>

        <button type="submit" class="btn btn-primary mt-2">Comprar</button>
    </form>
@endsection
