@extends('layouts.main')

@section('titlePage', 'Editando Produto')

@section('content')
    <h3>Editando {{ $produto->produto }}</h3>
    <form action="{{ route('produto.update', $produto->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label>Preço do Produto</label>
            <input type="text" name="Preço" class="form-control shadow-none" placeholder="Preço do Produto"
                value="{{ $produto->preço }}">
        </div>
        <div class="form-group">
            <label>Quantidade do Produto</label>
            <input type="text" name="Quantidade" class="form-control shadow-none" placeholder="Quantidade do Produto"
                value="{{ $carro->marca }}">
        </div>
        <button type="submit" class="btn btn-primary mt-2">Editar Produto</button>
    </form>
@endsection
