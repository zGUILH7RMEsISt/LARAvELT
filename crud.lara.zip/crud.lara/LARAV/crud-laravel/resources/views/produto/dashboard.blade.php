@extends('layouts.main')

@section('titlePage', 'Produto')

@section('content')

    <table class="table">
        <thead class="thead-dark">
            <tr>
                <th scope="col">Produto</th>
                <th scope="col">Preço</th>
                <th scope="col">Quantidade</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($produto as $produto)
                <tr>
                    <td>{{ $produto->Produto }}</td>
                    <td>{{ $carro->Preço }}</td>
                    <td>{{ $carro->Quantidade }}</td>
                    <th>
                        <a href="{{ route('produto.edit', $produto->id) }}" class="btn btn-success"> Editar </a>
                        <form action="{{ route('carros.destroy', $carro->id) }}" method="post">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Deletar</button>
                        </form>
                    </th>
                </tr>
            @endforeach

        </tbody>
    </table>

@endsection
