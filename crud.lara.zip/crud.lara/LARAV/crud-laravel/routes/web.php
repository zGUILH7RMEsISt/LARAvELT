<?php

use App\Http\Controllers\CarrosCotroller;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
  return view('produto.create');
});


Route::get("/create", [produtoCotroller::class, 'create'])->name("produto.create");
Route::post("/store", [produtoCotroller::class, 'store'])->name("produto.store");

Route::get("/dashboard", [produtoCotroller::class, 'dashboard'])->name("produto.dashboard");

Route::get("/edit/{id}", [produtoCotroller::class, 'edit'])->name("produto.edit");
Route::put("/update/{id}", [produtoCotroller::class, 'update'])->name("produto.update");


Route::delete("/delete/{id}", [produtoCotroller::class, 'destroy'])->name("produto.destroy");
